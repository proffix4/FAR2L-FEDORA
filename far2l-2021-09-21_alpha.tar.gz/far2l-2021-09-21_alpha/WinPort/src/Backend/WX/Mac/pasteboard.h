#pragma once

void CopyToPasteboard(const char* szText);
void CopyToPasteboard(const wchar_t* wszText);
