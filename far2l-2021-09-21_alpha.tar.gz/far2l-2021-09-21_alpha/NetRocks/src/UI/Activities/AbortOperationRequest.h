#pragma once
#include "../Defs.h"

void AbortOperationRequest(ProgressState &state, bool force_immediate = false);
